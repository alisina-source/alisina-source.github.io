import fs from 'node:fs';
for(const dir of ['media','logos']) {for(const file of fs.readdirSync('dist/'+dir)) fs.renameSync('dist/'+dir+'/'+file,'dist/'+file); fs.rmdirSync('dist/'+dir);}
