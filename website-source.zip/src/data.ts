export const sections=['About Me','Education','Experience','Projects','Work Albums','Skills','Achievements','Activities & Interests','Blog / Journal'];
export type Media={key:string;type:string;name:string;caption:string};
export type Entry={id:string;section:string;title:string;organization:string;period:string;description:string;parentEntryId?:string;organizationEmail?:string;organizationWebsite?:string;organizationPhone?:string;organizationContact?:string;organizationAddress?:string;media:Media[]};
export type Portfolio={name:string;headline:string;intro:string;location:string;email:string;phone?:string;whatsapp?:string;linkedin?:string;website?:string;entries:Entry[]};
export const initial:Portfolio={name:'Ali',headline:'Automotive Parts & E-commerce',intro:'I work remotely in automotive parts, supporting inventory, online listings, pricing and accurate product information.',location:'Afghanistan · Working remotely',email:'',entries:[{id:'experience-1',section:'Experience',title:'Automotive Parts Inventory & E-commerce Coordinator',organization:'Absolute Auto Parts · Remote',period:'',description:`Support automotive parts inventory and online sales.

• Enter vehicle details, parts information and photographs in Pinnacle.
• Create listings on Facebook Marketplace and Gumtree Australia.
• Correct invoices in Zoho CRM.
• Research parts compatibility and support product pricing.`,media:[]},{id:'skills-1',section:'Skills',title:'Inventory & online sales',organization:'',period:'',description:'Automotive parts research · Inventory data entry · E-commerce listings · Product pricing · Pinnacle · Zoho CRM · Facebook Marketplace · Gumtree',media:[]}]};
