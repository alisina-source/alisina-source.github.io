import React from 'react';
import {createRoot} from 'react-dom/client';
import PortfolioView from './portfolio-view';

import './globals.css';
fetch('/portfolio.json', {cache:'no-store'}).then(r=>{if(!r.ok)throw Error('Could not load portfolio');return r.json();}).then(data=>{document.title=data.name+' — Professional Portfolio';createRoot(document.getElementById('root')!).render(<PortfolioView initialData={data} loadError=""/>);}).catch(()=>{document.getElementById('root')!.textContent='The portfolio could not load. Please refresh the page.';});
