// Uncompressed ZIP archives: standard CRC32 and UTF-8 filenames.
export function zipFiles(files: {name:string; bytes:Uint8Array}[]): Blob {
  const chunks: Uint8Array[]=[]; const directory:Uint8Array[]=[]; let offset=0;
  const encoder=new TextEncoder();
  for(const file of files){
    const name=encoder.encode(file.name); let crc=0xffffffff;
    for(const byte of file.bytes){crc^=byte;for(let n=0;n<8;n++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}
    crc=(crc^0xffffffff)>>>0;
    const local=new Uint8Array(30+name.length);const l=new DataView(local.buffer);
    l.setUint32(0,0x04034b50,true);l.setUint16(4,20,true);l.setUint16(6,0x800,true);
    l.setUint32(14,crc,true);l.setUint32(18,file.bytes.length,true);l.setUint32(22,file.bytes.length,true);l.setUint16(26,name.length,true);local.set(name,30);
    const central=new Uint8Array(46+name.length);const c=new DataView(central.buffer);
    c.setUint32(0,0x02014b50,true);c.setUint16(4,20,true);c.setUint16(6,20,true);c.setUint16(8,0x800,true);
    c.setUint32(16,crc,true);c.setUint32(20,file.bytes.length,true);c.setUint32(24,file.bytes.length,true);c.setUint16(28,name.length,true);c.setUint32(42,offset,true);central.set(name,46);
    chunks.push(local,file.bytes);directory.push(central);offset+=local.length+file.bytes.length;
  }
  const size=directory.reduce((n,b)=>n+b.length,0);const end=new Uint8Array(22);const e=new DataView(end.buffer);
  e.setUint32(0,0x06054b50,true);e.setUint16(8,files.length,true);e.setUint16(10,files.length,true);e.setUint32(12,size,true);e.setUint32(16,offset,true);
  return new Blob([...chunks,...directory,end] as BlobPart[],{type:'application/zip'});
}
