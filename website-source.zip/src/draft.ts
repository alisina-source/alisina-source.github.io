import {Portfolio} from './data';
import {zipFiles} from './zip';
const uploads=new Map<string,File>();const urls=new Map<string,string>();
const allowed=new Set(['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','video/quicktime']);
export function mediaURL(key:string){return urls.get(key)||'https://alisina-source.github.io/'+encodeURIComponent(key);}
export async function draftFetch(path:string,init:RequestInit){
  if(path==='/api/portfolio')return Response.json({ok:true});
  if(path==='/api/upload'){
    const file=(init.body as FormData).get('file');
    if(!(file instanceof File))return Response.json({error:'Choose a file.'},{status:400});
    if(!allowed.has(file.type))return Response.json({error:'Use JPG, PNG, WebP, GIF, MP4, WebM or MOV.'},{status:400});
    if(file.size>25*1024*1024)return Response.json({error:'For GitHub browser uploads, each file must be 25 MiB or smaller.'},{status:400});
    const ext=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov'} as Record<string,string>)[file.type];
    const key=crypto.randomUUID()+'.'+ext;uploads.set(key,file);urls.set(key,URL.createObjectURL(file));
    return Response.json({key,type:file.type,name:file.name,caption:''});
  }
  return Response.json({error:'Unknown draft operation.'},{status:400});
}
export async function downloadChanges(data:Portfolio){
  const files=[{name:'portfolio.json',bytes:new TextEncoder().encode(JSON.stringify(data,null,2))}];
  const referenced=new Set([...data.entries.flatMap(e=>e.media),...(data.logos||[]),...(data.heroMedia||[])].map(m=>m.key));
  for(const [key,file] of uploads)if(referenced.has(key))files.push({name:key,bytes:new Uint8Array(await file.arrayBuffer())});
  const url=URL.createObjectURL(zipFiles(files));const link=document.createElement('a');link.href=url;link.download='portfolio-changes.zip';link.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
}

export async function publishChanges(data:Portfolio){
  const referenced=new Set([...data.entries.flatMap(e=>e.media),...(data.logos||[]),...(data.heroMedia||[])].map(m=>m.key));
  const selected=[...uploads].filter(([key])=>referenced.has(key));
  if(selected.reduce((n,[,f])=>n+f.size,0)>80*1024*1024)throw Error('Publish at most 80 MiB of new media at a time.');
  const encoded=await Promise.all(selected.map(async([key,file])=>({key,content:await new Promise<string>((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('Could not read media.'));reader.readAsDataURL(file);})})));
  const response=await fetch('/publish',{method:'POST',headers:{'Content-Type':'application/json','X-Local-Key':(window as any).__LOCAL_KEY__},body:JSON.stringify({data,uploads:encoded})});
  const result=await response.json();if(!response.ok)throw Error(result.error||'Publish failed.');
  for(const [key] of selected)uploads.delete(key);
  return result.message;
}
