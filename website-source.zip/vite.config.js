export default {build:{assetsDir:''}};
